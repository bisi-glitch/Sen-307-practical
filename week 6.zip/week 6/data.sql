
USE sen_307_12356;

-- =========================================
-- 1. CLEAR EXISTING PRACTICAL DATA
-- =========================================

SET FOREIGN_KEY_CHECKS = 0;

TRUNCATE TABLE Enrolment;
TRUNCATE TABLE CourseAllocation;
TRUNCATE TABLE Student;
TRUNCATE TABLE Lecturer;
TRUNCATE TABLE Course;
TRUNCATE TABLE Department;

SET FOREIGN_KEY_CHECKS = 1;


-- =========================================
-- 2. INSERT DEPARTMENTS
-- =========================================

INSERT INTO Department (dept_name)
VALUES
('Software Engineering'),
('Computer Science'),
('Artificial Intelligence'),
('Data Science'),
('Cybersecurity');


-- =========================================
-- 3. INSERT COURSES
-- =========================================

INSERT INTO Course (course_code, course_title, credit_units, description, dept_id)
VALUES
('SEN307', 'Database Systems', 3,
'Relational database design, SQL queries, normalization, transactions and indexing using MySQL.',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('SEN301', 'Software Architecture', 3,
'Architectural styles, design patterns, microservices and how to structure large software systems.',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('COS301', 'Operating Systems', 3,
'Processes, threads, CPU scheduling, memory management and file systems.',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('COS305', 'Computer Networks', 3,
'TCP/IP, routing, switching, LAN and WAN design and network protocols.',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('AIN301', 'Introduction to Artificial Intelligence', 3,
'Intelligent agents, search algorithms, knowledge representation and reasoning.',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('AIN305', 'Machine Learning', 3,
'Supervised and unsupervised learning, neural networks, deep learning and model evaluation.',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('AIN307', 'Natural Language Processing', 3,
'Text processing, word embeddings, language models, sentiment analysis and chatbots.',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('DTS301', 'Data Visualization and Analytics', 2,
'Exploratory data analysis, charts, dashboards and telling stories with data.',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('DTS305', 'Big Data Technologies', 3,
'Distributed storage and processing of very large datasets with Hadoop and Spark.',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('CYB301', 'Network Security', 3,
'Firewalls, cryptography, intrusion detection and protecting networks from attacks.',
(SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity'));


-- =========================================
-- 4. INSERT LECTURERS
-- =========================================

INSERT INTO Lecturer (staff_no, full_name, email, dept_id)
VALUES
('VUA/ST/101', 'Dr Amaka Okafor', 'a.okafor@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('VUA/ST/102', 'Dr Musa Bello', 'm.bello@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('VUA/ST/103', 'Dr Chinedu Eze', 'c.eze@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('VUA/ST/104', 'Dr Fatima Ibrahim', 'f.ibrahim@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('VUA/ST/105', 'Dr Kelechi Nwosu', 'k.nwosu@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('VUA/ST/106', 'Dr Aisha Yusuf', 'a.yusuf@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('VUA/ST/107', 'Dr Samuel Adeyemi', 's.adeyemi@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('VUA/ST/108', 'Dr Ngozi Okeke', 'n.okeke@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('VUA/ST/109', 'Dr Ibrahim Danjuma', 'i.danjuma@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity')),

('VUA/ST/110', 'Dr Esther James', 'e.james@vua.edu.ng',
(SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity'));


-- =========================================
-- 5. INSERT 20 STUDENTS
-- =========================================

INSERT INTO Student (matric_no, full_name, phone, gender, date_of_birth, dept_id)
VALUES
('20231234', 'Ada Obi', '08030000001', 'F', '2005-03-14',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('20231235', 'John Musa', '08030000002', 'M', '2004-11-02',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('20231236', 'Chika Okoro', '08030000003', 'F', '2003-07-21',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('20231237', 'Tunde Bakare', '08030000004', 'M', '2006-01-15',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('20231238', 'Zainab Yusuf', '08030000005', 'F', '2005-09-08',
(SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity')),

('20231239', 'Emeka Nwosu', '08030000006', 'M', '2004-05-19',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('20231240', 'Aisha Bello', '08030000007', 'F', '2007-02-11',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('20231241', 'David Eze', '08030000008', 'M', '2003-12-03',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('20231242', 'Fatima Ibrahim', '08030000009', 'F', '2006-06-25',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('20231243', 'Samuel Adeyemi', '08030000010', 'M', '2005-04-17',
(SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity')),

('20231244', 'Ifeoma Nnamdi', '08030000011', 'F', '2004-08-30',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('20231245', 'Chinedu Umeh', '08030000012', 'M', '2007-10-12',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('20231246', 'Maryam Sani', '08030000013', 'F', '2003-03-09',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('20231247', 'Kelechi Opara', '08030000014', 'M', '2006-11-22',
(SELECT dept_id FROM Department WHERE dept_name = 'Data Science')),

('20231248', 'Grace Onyekachi', '08030000015', 'F', '2005-01-28',
(SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity')),

('20231249', 'Ibrahim Danjuma', '08030000016', 'M', '2004-02-16',
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('20231250', 'Esther James', '08030000017', 'F', '2007-07-04',
(SELECT dept_id FROM Department WHERE dept_name = 'Computer Science')),

('20231251', 'Peter Ojo', '08030000018', 'M', '2003-09-14',
(SELECT dept_id FROM Department WHERE dept_name = 'Artificial Intelligence')),

('12356', 'Nkemdilim Ezekakpu', NULL, 'F', NULL,
(SELECT dept_id FROM Department WHERE dept_name = 'Software Engineering')),

('20231253', 'Mohammed Lawal', '08030000020', 'M', '2006-12-19',
(SELECT dept_id FROM Department WHERE dept_name = 'Cybersecurity'));


-- =========================================
-- 6. INSERT 40 ENROLMENTS
-- Peter Ojo and Mohammed Lawal have none.
-- =========================================

INSERT INTO Enrolment (student_id, course_id)
VALUES

((SELECT student_id FROM Student WHERE matric_no='20231234'), (SELECT course_id FROM Course WHERE course_code='SEN307')),
((SELECT student_id FROM Student WHERE matric_no='20231235'), (SELECT course_id FROM Course WHERE course_code='SEN307')),
((SELECT student_id FROM Student WHERE matric_no='20231236'), (SELECT course_id FROM Course WHERE course_code='SEN307')),
((SELECT student_id FROM Student WHERE matric_no='20231237'), (SELECT course_id FROM Course WHERE course_code='SEN307')),
((SELECT student_id FROM Student WHERE matric_no='20231238'), (SELECT course_id FROM Course WHERE course_code='SEN307')),
((SELECT student_id FROM Student WHERE matric_no='20231239'), (SELECT course_id FROM Course WHERE course_code='SEN307')),
((SELECT student_id FROM Student WHERE matric_no='20231240'), (SELECT course_id FROM Course WHERE course_code='SEN307')),
((SELECT student_id FROM Student WHERE matric_no='20231241'), (SELECT course_id FROM Course WHERE course_code='SEN307')),

((SELECT student_id FROM Student WHERE matric_no='20231242'), (SELECT course_id FROM Course WHERE course_code='DTS301')),
((SELECT student_id FROM Student WHERE matric_no='20231243'), (SELECT course_id FROM Course WHERE course_code='CYB301')),
((SELECT student_id FROM Student WHERE matric_no='20231244'), (SELECT course_id FROM Course WHERE course_code='SEN301')),
((SELECT student_id FROM Student WHERE matric_no='20231245'), (SELECT course_id FROM Course WHERE course_code='COS301')),
((SELECT student_id FROM Student WHERE matric_no='20231246'), (SELECT course_id FROM Course WHERE course_code='AIN301')),
((SELECT student_id FROM Student WHERE matric_no='20231247'), (SELECT course_id FROM Course WHERE course_code='DTS305')),
((SELECT student_id FROM Student WHERE matric_no='20231248'), (SELECT course_id FROM Course WHERE course_code='CYB301')),
((SELECT student_id FROM Student WHERE matric_no='20231249'), (SELECT course_id FROM Course WHERE course_code='SEN301')),
((SELECT student_id FROM Student WHERE matric_no='20231250'), (SELECT course_id FROM Course WHERE course_code='COS305')),

((SELECT student_id FROM Student WHERE matric_no='12356'), (SELECT course_id FROM Course WHERE course_code='SEN307')),

((SELECT student_id FROM Student WHERE matric_no='20231234'), (SELECT course_id FROM Course WHERE course_code='SEN301')),
((SELECT student_id FROM Student WHERE matric_no='20231235'), (SELECT course_id FROM Course WHERE course_code='COS301')),
((SELECT student_id FROM Student WHERE matric_no='20231236'), (SELECT course_id FROM Course WHERE course_code='AIN301')),
((SELECT student_id FROM Student WHERE matric_no='20231237'), (SELECT course_id FROM Course WHERE course_code='DTS305')),
((SELECT student_id FROM Student WHERE matric_no='20231238'), (SELECT course_id FROM Course WHERE course_code='CYB301')),
((SELECT student_id FROM Student WHERE matric_no='20231239'), (SELECT course_id FROM Course WHERE course_code='COS305')),
((SELECT student_id FROM Student WHERE matric_no='20231240'), (SELECT course_id FROM Course WHERE course_code='AIN305')),
((SELECT student_id FROM Student WHERE matric_no='20231241'), (SELECT course_id FROM Course WHERE course_code='AIN307')),
((SELECT student_id FROM Student WHERE matric_no='20231242'), (SELECT course_id FROM Course WHERE course_code='DTS305')),
((SELECT student_id FROM Student WHERE matric_no='20231243'), (SELECT course_id FROM Course WHERE course_code='SEN301')),
((SELECT student_id FROM Student WHERE matric_no='20231244'), (SELECT course_id FROM Course WHERE course_code='COS301')),
((SELECT student_id FROM Student WHERE matric_no='20231245'), (SELECT course_id FROM Course WHERE course_code='COS305')),
((SELECT student_id FROM Student WHERE matric_no='20231246'), (SELECT course_id FROM Course WHERE course_code='AIN305')),
((SELECT student_id FROM Student WHERE matric_no='20231247'), (SELECT course_id FROM Course WHERE course_code='AIN307')),
((SELECT student_id FROM Student WHERE matric_no='20231248'), (SELECT course_id FROM Course WHERE course_code='AIN301')),
((SELECT student_id FROM Student WHERE matric_no='20231249'), (SELECT course_id FROM Course WHERE course_code='DTS301')),
((SELECT student_id FROM Student WHERE matric_no='20231250'), (SELECT course_id FROM Course WHERE course_code='CYB301')),

((SELECT student_id FROM Student WHERE matric_no='12356'), (SELECT course_id FROM Course WHERE course_code='SEN301')),
((SELECT student_id FROM Student WHERE matric_no='20231234'), (SELECT course_id FROM Course WHERE course_code='AIN305')),
((SELECT student_id FROM Student WHERE matric_no='20231235'), (SELECT course_id FROM Course WHERE course_code='AIN307')),
((SELECT student_id FROM Student WHERE matric_no='20231236'), (SELECT course_id FROM Course WHERE course_code='SEN301'));


-- =========================================
-- 7. INSERT 11 COURSE ALLOCATIONS
-- SEN307 has two lecturers.
-- =========================================

INSERT INTO CourseAllocation (course_id, lecturer_id)
VALUES
((SELECT course_id FROM Course WHERE course_code='SEN307'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/101')),
((SELECT course_id FROM Course WHERE course_code='SEN307'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/102')),
((SELECT course_id FROM Course WHERE course_code='SEN301'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/101')),
((SELECT course_id FROM Course WHERE course_code='COS301'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/103')),
((SELECT course_id FROM Course WHERE course_code='COS305'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/104')),
((SELECT course_id FROM Course WHERE course_code='AIN301'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/105')),
((SELECT course_id FROM Course WHERE course_code='AIN305'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/106')),
((SELECT course_id FROM Course WHERE course_code='AIN307'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/105')),
((SELECT course_id FROM Course WHERE course_code='DTS301'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/107')),
((SELECT course_id FROM Course WHERE course_code='DTS305'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/108')),
((SELECT course_id FROM Course WHERE course_code='CYB301'), (SELECT lecturer_id FROM Lecturer WHERE staff_no='VUA/ST/109'));


-- =========================================
-- 8. UPDATE ADA OBI'S DEPARTMENT
-- =========================================

UPDATE Student
SET dept_id = (
    SELECT dept_id FROM Department
    WHERE dept_name = 'Computer Science'
)
WHERE matric_no = '20231234';


-- =========================================
-- 9. CHECK COUNTS BEFORE ERROR 1451 DEMO
-- =========================================

SELECT 'Department' AS table_name, COUNT(*) AS total FROM Department
UNION ALL
SELECT 'Lecturer', COUNT(*) FROM Lecturer
UNION ALL
SELECT 'Student', COUNT(*) FROM Student
UNION ALL
SELECT 'Course', COUNT(*) FROM Course
UNION ALL
SELECT 'Enrolment', COUNT(*) FROM Enrolment
UNION ALL
SELECT 'CourseAllocation', COUNT(*) FROM CourseAllocation;


INSERT INTO Department (dept_name)
VALUES ('Library and Information Science');


INSERT INTO Student (matric_no, full_name, dept_id)
VALUES (
    '20239999',
    'Transfer Student',
    (SELECT dept_id
     FROM Department
     WHERE dept_name = 'Library and Information Science')
);


DELETE FROM Department
WHERE dept_name = 'Library and Information Science';


UPDATE Student
SET dept_id = (
    SELECT dept_id
    FROM Department
    WHERE dept_name = 'Software Engineering'
)
WHERE matric_no = '20239999';


DELETE FROM Department
WHERE dept_name = 'Library and Information Science';


SELECT 'Department' AS table_name, COUNT(*) AS total FROM Department
UNION ALL
SELECT 'Lecturer', COUNT(*) FROM Lecturer
UNION ALL
SELECT 'Student', COUNT(*) FROM Student
UNION ALL
SELECT 'Course', COUNT(*) FROM Course
UNION ALL
SELECT 'Enrolment', COUNT(*) FROM Enrolment
UNION ALL
SELECT 'CourseAllocation', COUNT(*) FROM CourseAllocation;



SELECT c.course_code, COUNT(*) AS total_students
FROM Course c
JOIN Enrolment e ON c.course_id = e.course_id
WHERE c.course_code = 'SEN307'
GROUP BY c.course_code;


SELECT c.course_code, COUNT(*) AS total_lecturers
FROM Course c
JOIN CourseAllocation ca ON c.course_id = ca.course_id
WHERE c.course_code = 'SEN307'
GROUP BY c.course_code;

