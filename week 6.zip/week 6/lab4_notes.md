
# Week 6 Practical – Data Manipulation Language (DML)

## Introduction

This practical focused on Data Manipulation Language (DML) in MySQL. I used INSERT, UPDATE and DELETE statements to manage records in my university database.

## Activities Carried Out

- Inserted records into the Department, Course, Lecturer and Student tables.
- Added 40 student enrolments.
- Assigned lecturers to courses using the CourseAllocation table.
- Updated a student's department using the UPDATE statement.
- Tested how foreign key constraints affect the deletion of records.
- Used SELECT queries to verify the database records.

## Referential Integrity and Error 1451

I created a department named Library and Information Science and assigned a student to it. When I attempted to delete the department, MySQL returned Error 1451 because the student still referenced that department.

This showed how foreign key constraints protect referential integrity by preventing the deletion of records that are still being referenced by other tables.

To resolve the error, I reassigned the student to the Software Engineering department before deleting the Library and Information Science department.

## Conclusion

This practical helped me understand how INSERT, UPDATE and DELETE statements work in MySQL. I also learned how foreign key constraints maintain relationships between tables and prevent invalid changes to related records.
